# HABITA Salud 1.0

Extrae TODO el ZIP y abre index.html en Chrome, Edge o Firefox. En Windows también puedes ejecutar INICIAR_HABITA.bat. Mantén juntos los archivos. No requiere Python, instalación, servidor ni Internet.

Inicio: punto de prueba San Bernardo (-33.5695332,-70.7022501), atención primaria pública, radio 2 km. Otros perfiles: urgencias; hospitales/clínicas; atención presencial general. Radios: 500 m a 10 km. Prestadores: público, privado, ambos; excluye FFAA y sin clasificación. Cambiar perfil, prestador o radio recalcula. Cambiar coordenadas requiere pulsar Analizar.

Fuente: IDE MINSAL, catastro 12/06/2026; descarga 18/10/2026. Original incluido en fuentes/. 5.295 registros nacionales, 1.071 RM (COD_REG=13), 52 códigos comunales. data.js es el extracto RM con código COD_VIG, coordenadas y atributos de consulta. Sin actualización automática.
https://www.minsal.cl/ide-minsal-geoportal-descarga-de-datos/
https://www.minsal.cl/wp-content/uploads/2026/08/ESTABLECIMIENTOS_12062026_DES.zip

Primaria: CESFAM, CECOSF, PSR, CGR y CGU. Urgencias: SAPU, SAR, SUR y hospitales/clínicas con urgencia SI; excluye reguladores SAMU. Hospitales: Hospital y Clínica. General: lista explícita de atención presencial (ver engine.js), incluye atención especializada, dental, mental y rehabilitación; no significa equivalencia clínica. Administración, atención remota, móvil y SML quedan fuera.

Haversine, R=6.371.000 m, línea recta. No son distancias por calles, tiempos ni puntajes. 2 km es un parámetro exploratorio, no norma oficial. Busca en toda la RM, sin cortar por comuna. Validación del punto mediante envolvente amplia aproximada, no polígono; no acredita pertenencia regional. Oferta de otras regiones no incluida.

Recintos aproximados agrupa coordenadas a seis decimales: no prueba identidad física. Se conservan registros separados por código. Esquema sin mapa base, norte arriba, hasta 40 servicios; puede haber superposición. Números vinculados a la tabla.

Buscar texto filtra solo la tabla, no métricas ni exportación. JSON/CSV incluyen todos los resultados del radio; JSON también incluye parámetros, fuente, método y más cercano aunque quede fuera del radio. Los enlaces Google Maps comparten coordenadas del establecimiento al abrirlos. No hay telemetría ni conexiones de red al iniciar.

No informa cupos, esperas, horarios, admisión ni funcionamiento actual. No se usa complejidad como capacidad. Capas administrativas SEREMIs/Servicios de Salud no incluidas: innecesarias para esta consulta de proximidad.

Validación: motor comprobado contra distancia cero, un grado, entradas inválidas y ejemplo San Bernardo (3 servicios APS públicos dentro de 2 km, Carol Urzúa ~709 m; 290 elegibles). Integración verificada con DOM simulado, cambios de perfil y limpieza ante error. Sintaxis JS comprobada. No fue posible inspección visual en navegador: el entorno bloqueó archivos locales.

## Ubicaciones de prueba incorporadas
Las ocho ubicaciones de UBICACIONES DE PRUEBA(1).txt están disponibles en Consulta rápida con sus coordenadas exactas (latitud, longitud). Se conserva San Bernardo y Otra ubicación. Seleccionar una ubicación actualiza nombre, coordenadas y resultados automáticamente.
- Palacio de La Moneda: -33.4422475, -70.653898
- Costanera Center (Cenco Costanera): -33.4173748, -70.6072617
- Estadio Nacional Julio Martínez Prádanos: -33.4644994, -70.6112756
- Aeropuerto Internacional Arturo Merino Benítez: -33.3972119, -70.7930097
- Cerro San Cristóbal — acceso Pío Nono: -33.4304869, -70.6353589
- Hospital Dr. Sótero del Río: -33.5770095, -70.5812289
- Estación Intermodal La Cisterna: -33.5382168, -70.6641985
- Observatorio Astronómico Nacional — Cerro Calán: -33.3964895, -70.5370203
